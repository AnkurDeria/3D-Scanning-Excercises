#pragma once

const float PI = 3.14159f;
const float GRADE_BONUS = 0.3f;
