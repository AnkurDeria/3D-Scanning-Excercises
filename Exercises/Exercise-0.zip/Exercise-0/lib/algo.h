#pragma once

#include <vector>
#include <algorithm>

namespace Algos
{
	void sort(std::vector<float>& values);
}
