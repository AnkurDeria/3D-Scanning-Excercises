#include "algo.h"

void Algos::sort(std::vector<float>& values)
{
	std::sort(values.begin(), values.end());
}
